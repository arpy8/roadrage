# RoadRash - A python package developed to play `Road Rage` game from hand gestures 

Simple run the following command in your **command prompt**
`
pip install roadrage && roadrage
`